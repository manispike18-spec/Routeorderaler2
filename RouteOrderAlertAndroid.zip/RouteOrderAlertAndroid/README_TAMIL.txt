Route Order Alert — Android source prototype (APK அல்ல)

இது உண்மையான, நிறுவத் தயாரான APK அல்ல. Android Studio/CI மூலம் build செய்ய வேண்டிய source project.

தற்போதைய செயல்பாடு:
- Android notification listener service-க்கான அடிப்படை அமைப்பு.
- Notification Access settings திறக்கும் app screen.
- Notifications-ஐ தானாகப் படிக்கும் அனுமதி கொடுத்த பிறகு, development log-ல் package/title/text வரலாம்.

இன்னும் இல்லை:
- Swiggy / Ek Bharat notification-ஐ நம்பகமாக அடையாளம் காணுதல்.
- Pickup/drop முகவரிகளைத் தானாக extract செய்தல்.
- உண்மையான road route matching.
- பொருத்தமான ஆர்டருக்கான automatic route alert.

தனியுரிமை: notification-களில் தனிப்பட்ட தகவல்கள் இருக்கலாம். இந்த prototype content-ஐ app storage-ல் சேமிக்காது; development log-ல் எழுதுகிறது. இதை வெளியிடும் முன் logging நீக்கி, அனுமதிகளை/தனியுரிமையைச் சோதிக்க வேண்டும்.

Build: GitHub repository-க்கு upload செய்து Actions workflow இயக்கலாம்; அது debug APK artifact உருவாக்கும். Build முடிந்த பிறகும் இந்த prototype route-matching app ஆகாது.
